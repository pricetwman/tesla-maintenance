import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Gauge, c as Check, i as Info, n as TriangleAlert, o as Clock, r as ShieldCheck, s as ChevronDown, t as Wrench } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-hSyFydq6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var MODELS = [
	{
		id: "3",
		name: "Model 3",
		fullName: "Model 3 / Highland",
		cabinFilter: "每 2 年（台灣環境建議每年）",
		hepa: false,
		heatPumpNote: "約 2021 年起多數配備熱泵；舊款無熱泵才需定期換乾燥包。"
	},
	{
		id: "y",
		name: "Model Y",
		fullName: "Model Y / Juniper",
		cabinFilter: "每 2 年（台灣環境建議每年）",
		hepa: true,
		heatPumpNote: "全車系熱泵；乾燥包多數不需定期更換。"
	},
	{
		id: "s",
		name: "Model S",
		fullName: "Model S",
		cabinFilter: "每 3 年（2012–2020 建議每 2 年）",
		hepa: true,
		heatPumpNote: "新款熱泵；舊款乾燥包週期較短。"
	},
	{
		id: "x",
		name: "Model X",
		fullName: "Model X",
		cabinFilter: "每 3 年（2015–2020 建議每 2 年）",
		hepa: true,
		heatPumpNote: "新款熱泵；舊款乾燥包約每 4 年。"
	},
	{
		id: "ct",
		name: "Cybertruck",
		fullName: "Cybertruck",
		cabinFilter: "無標準車廂濾網；HEPA 每 2 年",
		hepa: true,
		heatPumpNote: "乾燥包約每 8 年。"
	}
];
var ITEMS = [
	{
		id: "tire-rotate",
		name: "輪胎換位",
		kind: "official",
		group: "輪胎底盤",
		intervalKm: 1e4,
		intervalLabel: "每 10,000 km",
		official: "每 10,000 km，或前後胎紋差達 1.5 mm，以先到者為準。",
		notes: "電動車瞬間扭力會讓驅動輪磨得較快。RWD 後輪、AWD 四輪都要規律對調，才能維持續航與抓地。Model X 前後輪規格不同時無法交叉對調。",
		appliesTo: "all"
	},
	{
		id: "tire-align",
		name: "四輪定位",
		kind: "preventive",
		group: "輪胎底盤",
		intervalKm: 4e4,
		intervalLabel: "約 40,000 km 或跑偏時",
		official: "無固定週期；輪胎異常磨損或方向盤跑偏時進行。",
		practice: "台灣路況建議每 4 萬公里或換胎時檢查。",
		notes: "路肩、坑洞、高速過彎後若方向盤不平，應盡快定位，避免單邊磨胎。",
		appliesTo: "all"
	},
	{
		id: "chassis",
		name: "底盤巡視與懸吊扭力",
		kind: "preventive",
		group: "輪胎底盤",
		intervalKm: 4e4,
		intervalYears: 2,
		intervalLabel: "約 2 年 / 4 萬 km",
		official: "依需要檢查，非強制年度大保養。",
		practice: "原廠價目表有底盤巡視項目，建議搭配濾網或煞車油一起做。",
		notes: "膠套、球頭、連桿異音多半在 6 萬公里後出現。聽到底盤異音不要拖。",
		appliesTo: "all"
	},
	{
		id: "cabin-filter",
		name: "車廂空氣濾網（冷氣濾網）",
		kind: "official",
		group: "空調空氣",
		intervalYears: 2,
		intervalLabel: "每 1–2 年",
		official: "Model 3 / Y：手冊每 2 年；台灣／香港支援頁常列每 12 個月。Model S / X：每 3 年（2012–2020 年 S/X 每 2 年）。",
		practice: "台灣潮濕、空品差，建議每年更換，有霉味或風量變小立刻換。",
		notes: "Model 3 / Y 一次需換兩片。原廠常見編號 1107681-00-A / B / C。車內「控制 → 服務 → 保養」會顯示到期時間。",
		parts: "1107681-00-A / 1107681-00-B / 1107681-00-C（3 / Y 兩片一組）",
		appliesTo: [
			"3",
			"y",
			"s",
			"x"
		]
	},
	{
		id: "hepa",
		name: "HEPA 濾網與活性碳濾網",
		kind: "official",
		group: "空調空氣",
		intervalYears: 3,
		intervalLabel: "每 3 年",
		official: "配備 HEPA 者每 3 年更換 HEPA 與碳濾網。中國地區建議每年。Cybertruck 每 2 年，越野／土路每年。",
		notes: "Model Y、S、X 與 Cybertruck 常見配備。生化武器防禦模式依賴這組濾網。",
		appliesTo: [
			"y",
			"s",
			"x",
			"ct"
		]
	},
	{
		id: "desiccant",
		name: "冷氣乾燥包",
		kind: "official",
		group: "空調空氣",
		intervalYears: 6,
		intervalLabel: "視熱泵／年式",
		official: "多數熱泵車型不需定期預約更換。無熱泵舊款：Model 3（2017–2023）約 6 年；Model S 2012–2020 約 2 年；Model X 2015–2020 約 4 年；Cybertruck 約 8 年。",
		notes: "車內「控制 → 軟體 → 其他車輛資訊」可看是否有熱泵。有熱泵者以車內保養摘要為準。",
		appliesTo: "all"
	},
	{
		id: "condenser",
		name: "冷凝器／散熱網清潔",
		kind: "preventive",
		group: "空調空氣",
		intervalKm: 2e4,
		intervalLabel: "每 1–2 萬 km",
		official: "灰塵環境下散熱器會堵塞，影響空調與電池散熱；依需要清潔。",
		practice: "台灣柳絮、落葉多，建議每 1–2 萬公里檢查前備箱進氣口與冷凝器。",
		notes: "斜置冷凝器容易只進不出。堵塞會讓壓縮機長時間高負荷，是壓縮機提前損壞的常見原因。可加裝防蟲網降低堆積。",
		appliesTo: "all"
	},
	{
		id: "wipers",
		name: "雨刷片",
		kind: "official",
		group: "空調空氣",
		intervalYears: 1,
		intervalLabel: "每年",
		official: "每年更換雨刷片。",
		notes: "可自行更換。雨刷水視需要補充。",
		appliesTo: "all"
	},
	{
		id: "brake-fluid",
		name: "煞車油檢查／更換",
		kind: "official",
		group: "煞車",
		intervalYears: 4,
		intervalLabel: "每 4 年",
		official: "每 4 年檢查煞車油狀況，必要時更換。",
		practice: "常拖車、下山、競技或炎熱潮濕環境需更頻繁。",
		notes: "動能回收讓摩擦煞車較少用，油品主要因吸水劣化，儀表不會主動提醒。不要自行補充煞車油。",
		appliesTo: "all"
	},
	{
		id: "calipers",
		name: "煞車卡鉗清潔潤滑",
		kind: "official",
		group: "煞車",
		intervalKm: 2e4,
		intervalYears: 1,
		intervalLabel: "每年或 2 萬 km",
		official: "冬季撒鹽路面：每年或每 20,000 km 清潔並潤滑卡鉗滑銷。一般地區每年清潔。",
		notes: "台灣不撒鹽，但仍建議每年檢查卡鉗是否卡死，避免長期不用導致咬死。",
		appliesTo: "all"
	},
	{
		id: "pads",
		name: "煞車來令片",
		kind: "lifetime",
		group: "煞車",
		intervalLabel: "視磨損，多數很久才換",
		official: "動能回收大幅減少磨損，無固定里程。",
		notes: "仍需目視檢查厚度。山路、拖車、關閉動能回收會加快磨耗。",
		appliesTo: "all"
	},
	{
		id: "drive-oil",
		name: "馬達油／減速器油",
		kind: "preventive",
		group: "動力冷卻",
		intervalKm: 8e4,
		intervalYears: 5,
		intervalLabel: "官方終身；預防性 6–12 萬 km",
		official: "驅動單元油列為終身免更換。特斯拉不需傳統機油保養。",
		practice: "獨立廠與高里程車主常見預防性更換：約 6–12 萬公里或 4–6 年。台灣高溫、市區走走停停可偏 6–8 萬公里。",
		notes: "這是齒輪潤滑油（ATF-9 / EDF2 / KAF1），不是引擎機油。原廠有「馬達油與油芯」服務項目。異音、漏粉紅油或買高里程二手車時優先檢查。",
		appliesTo: "all"
	},
	{
		id: "coolant",
		name: "電池冷卻液",
		kind: "lifetime",
		group: "動力冷卻",
		intervalLabel: "多數情況終身不換",
		official: "大多數情況下車輛壽命期間無需更換。液位僅能由 Tesla 或專業廠檢查。",
		notes: "自行打開冷卻液儲存缸造成的損壞不在保固範圍。",
		appliesTo: "all"
	},
	{
		id: "lv-battery",
		name: "低壓電瓶（12V / 16V）",
		kind: "preventive",
		group: "電系耗材",
		intervalYears: 4,
		intervalLabel: "約 3–6 年視狀況",
		official: "無固定週期；故障時更換。保固內部分可免費更換。",
		notes: "新款多為 16V 鋰電池。低壓電瓶老化會出現無法喚醒、中控當機、車門打不開。長期放置請保持適度電量。",
		appliesTo: "all"
	},
	{
		id: "cameras",
		name: "Autopilot 鏡頭清潔",
		kind: "official",
		group: "電系耗材",
		intervalLabel: "每週／視髒污",
		official: "定期清潔鏡頭與擋風玻璃內側攝影機區域。",
		notes: "髒污會影響輔助駕駛。前擋內側霧氣、油膜也要清。",
		appliesTo: "all"
	},
	{
		id: "engine-oil",
		name: "引擎機油、火星塞、燃油濾清器",
		kind: "not-needed",
		group: "不需保養",
		intervalLabel: "不需要",
		official: "純電無內燃機，不需換機油、火星塞、燃油系統或排放檢測。",
		notes: "「馬達油」是減速器齒輪油，與機油不是同一件事。",
		appliesTo: "all"
	}
];
var TIMELINE = [
	{
		id: "weekly",
		label: "日常／每週",
		hint: "自己就能做",
		itemIds: ["cameras"]
	},
	{
		id: "10k",
		label: "每 10,000 km",
		hint: "最常做的項目",
		itemIds: ["tire-rotate"]
	},
	{
		id: "yearly",
		label: "每年",
		hint: "台灣建議提前做濾網",
		itemIds: [
			"wipers",
			"cabin-filter",
			"calipers",
			"condenser"
		]
	},
	{
		id: "2y",
		label: "每 2 年／約 4 萬 km",
		hint: "官方濾網與底盤",
		itemIds: [
			"cabin-filter",
			"chassis",
			"tire-align"
		]
	},
	{
		id: "3y",
		label: "每 3 年",
		hint: "HEPA 車型",
		itemIds: ["hepa"]
	},
	{
		id: "4y",
		label: "每 4 年",
		hint: "煞車油與低壓電瓶觀察",
		itemIds: ["brake-fluid", "lv-battery"]
	},
	{
		id: "80k",
		label: "6–12 萬 km",
		hint: "預防性，非官方強制",
		itemIds: ["drive-oil"]
	},
	{
		id: "life",
		label: "終身／視需要",
		hint: "官方多數不排程",
		itemIds: [
			"coolant",
			"pads",
			"desiccant",
			"engine-oil"
		]
	}
];
function itemApplies(item, model) {
	return item.appliesTo === "all" || item.appliesTo.includes(model);
}
function dueStatus(item, km, years) {
	if (item.kind === "not-needed" || item.kind === "lifetime") return "na";
	const kmDue = item.intervalKm != null && km >= item.intervalKm;
	const yrDue = item.intervalYears != null && years >= item.intervalYears;
	if (kmDue || yrDue) return "due";
	if (item.intervalKm != null && km >= item.intervalKm * .8) return "soon";
	if (item.intervalYears != null && years >= item.intervalYears * .8) return "soon";
	return "ok";
}
function modelById(id) {
	return MODELS.find((m) => m.id === id) ?? MODELS[0];
}
var useGuide = create()(persist((set, get) => ({
	model: "y",
	km: 2e4,
	years: 1,
	done: [],
	setModel: (model) => set({ model }),
	setKm: (km) => set({ km }),
	setYears: (years) => set({ years }),
	toggleDone: (id) => {
		set({ done: get().done.includes(id) ? get().done.filter((x) => x !== id) : [...get().done, id] });
	}
}), { name: "tesla-service-guide" }));
var KIND_LABEL = {
	official: "官方建議",
	preventive: "預防性",
	lifetime: "終身／視需要",
	"not-needed": "不需要"
};
function KindChip({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", kind === "official" && "bg-fg/10 text-fg", kind === "preventive" && "bg-warn/15 text-warn", kind === "lifetime" && "bg-ok/15 text-ok", kind === "not-needed" && "bg-subtle/20 text-muted"),
		children: KIND_LABEL[kind]
	});
}
function ItemCard({ item, km, years, done, onToggle }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const status = dueStatus(item, km, years);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: cn("rounded-xl border border-border bg-surface p-4 md:p-5", done && "opacity-70"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onToggle,
				"aria-label": done ? "取消完成" : "標記完成",
				className: cn("mt-0.5 flex size-11 shrink-0 items-center justify-center rounded-md border transition-colors duration-150", done ? "border-ok bg-ok text-bg" : "border-border bg-elevated text-muted hover:border-fg/30"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
					className: "size-4",
					strokeWidth: 2.5
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-base font-semibold tracking-tight text-fg",
								children: item.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindChip, { kind: item.kind }),
							status === "due" && !done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 text-xs font-medium text-due",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3.5" }), "依輸入里程／年數已到期"]
							}),
							status === "soon" && !done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-warn",
								children: "即將到期"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-medium tabular-nums text-muted",
						children: item.intervalLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: item.official
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setOpen((v) => !v),
						className: "mt-3 inline-flex min-h-11 items-center gap-1 text-sm font-medium text-fg",
						children: [open ? "收合細節" : "看細節與實務建議", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-4 transition-transform duration-150", open && "rotate-180") })]
					}),
					open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 space-y-3 border-t border-border pt-3 text-sm leading-relaxed",
						children: [
							item.practice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-fg",
								children: "實務建議："
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [" ", item.practice]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: item.notes
							}),
							item.parts && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-subtle",
								children: ["零件編號 ", item.parts]
							})
						]
					})
				]
			})]
		})
	});
}
function MaintenanceGuide() {
	const { model, km, years, done, setModel, setKm, setYears, toggleDone } = useGuide();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [timelineId, setTimelineId] = (0, import_react.useState)(null);
	const current = modelById(model);
	const visible = (0, import_react.useMemo)(() => {
		let list = ITEMS.filter((i) => itemApplies(i, model));
		if (filter !== "all") list = list.filter((i) => i.kind === filter);
		if (timelineId) {
			const node = TIMELINE.find((t) => t.id === timelineId);
			if (node) list = list.filter((i) => node.itemIds.includes(i.id));
		}
		return list;
	}, [
		model,
		filter,
		timelineId
	]);
	const dueCount = ITEMS.filter((i) => itemApplies(i, model) && dueStatus(i, km, years) === "due" && i.kind !== "not-needed" && !done.includes(i.id)).length;
	const groups = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const item of visible) {
			const arr = map.get(item.group) ?? [];
			arr.push(item);
			map.set(item.group, arr);
		}
		return [...map.entries()];
	}, [visible]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-5xl items-center justify-between px-4 py-4 md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-9 items-center justify-center rounded-md bg-accent text-xs font-semibold tracking-widest text-accent-fg",
						children: "T"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-semibold tracking-tight",
						children: "Tesla 保養手冊"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: "全車時間與項目"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden text-xs text-subtle sm:block",
					children: "以車內保養摘要為準"
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-5xl px-4 pb-20 pt-8 md:px-6 md:pt-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-subtle",
					children: "Service calendar"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-3 max-w-2xl text-3xl font-semibold leading-tight tracking-tight md:text-5xl",
					children: "特斯拉全車保養時間與項目"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-base leading-relaxed text-muted",
					children: "官方手冊沒有年度大保養。下面整理必做項目、台灣環境建議，以及減速器油、冷凝器這類預防性保養。選車型、填里程，即可看出目前該注意什麼。"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 rounded-xl border border-border bg-surface p-4 md:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-fg",
							children: "選擇車型"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-5",
							children: MODELS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setModel(m.id),
								className: cn("min-h-11 rounded-md border px-3 py-2 text-sm font-medium transition-colors duration-150", model === m.id ? "border-fg bg-fg text-bg" : "border-border bg-elevated text-muted hover:text-fg"),
								children: m.name
							}, m.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted",
							children: [
								current.fullName,
								"　濾網：",
								current.cabinFilter
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-subtle",
							children: current.heatPumpNote
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2 text-sm font-medium text-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "size-4" }), "目前里程（公里）"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 0,
									step: 1e3,
									value: km,
									onChange: (e) => setKm(Number(e.target.value) || 0),
									className: "mt-2 h-11 w-full rounded-md border border-border bg-elevated px-3 tabular-nums text-fg outline-none ring-fg/40 focus:ring-2"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2 text-sm font-medium text-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" }), "持有年數"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 0,
									max: 20,
									step: .5,
									value: years,
									onChange: (e) => setYears(Number(e.target.value) || 0),
									className: "mt-2 h-11 w-full rounded-md border border-border bg-elevated px-3 tabular-nums text-fg outline-none ring-fg/40 focus:ring-2"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap items-center gap-3 rounded-lg bg-elevated px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-ok" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [
									"依目前輸入，有",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "tabular-nums text-fg",
										children: dueCount
									}),
									" 項已達官方或預防性週期（未勾完成）。"
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-semibold tracking-tight",
							children: "時間軸"
						}), timelineId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setTimelineId(null),
							className: "min-h-11 text-sm text-muted hover:text-fg",
							children: "顯示全部項目"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4",
						children: TIMELINE.map((node) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTimelineId(timelineId === node.id ? null : node.id),
							className: cn("rounded-lg border p-4 text-left transition-colors duration-150", timelineId === node.id ? "border-fg bg-elevated" : "border-border bg-surface hover:border-fg/25"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm font-semibold",
								children: node.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-subtle",
								children: node.hint
							})]
						}, node.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							"all",
							"official",
							"preventive",
							"lifetime",
							"not-needed"
						].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setFilter(f),
							className: cn("min-h-11 rounded-full border px-4 text-sm font-medium", filter === f ? "border-fg bg-fg text-bg" : "border-border bg-transparent text-muted hover:text-fg"),
							children: f === "all" ? "全部" : KIND_LABEL[f]
						}, f))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 space-y-8",
						children: [groups.map(([group, items]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mb-3 text-xs font-medium uppercase tracking-[0.16em] text-subtle",
							children: group
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemCard, {
								item,
								km,
								years,
								done: done.includes(item.id),
								onToggle: () => toggleDone(item.id)
							}, item.id))
						})] }, group)), groups.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-lg border border-border bg-surface px-4 py-8 text-center text-sm text-muted",
							children: "這個車型在此篩選下沒有對應項目。"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mt-12 rounded-xl border border-border bg-surface p-5 md:p-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "mt-0.5 size-5 shrink-0 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-semibold",
							children: "如何避免壓縮機提前損壞"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-3 list-disc space-y-2 pl-5 text-sm leading-relaxed text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "定期清冷凝器與進氣口，不要讓樹葉、柳絮堵住散熱。" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "準時換空調濾網，避免系統高風阻運轉。" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "冷氣不冷、異音或儀表提示氣候系統故障，立刻檢查，不要硬開。" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "聽到高頻嘯叫尤其是冷車時，盡快送修，避免金屬屑污染整組管路。" })
							]
						})] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "mt-10 flex items-start gap-2 text-xs leading-relaxed text-subtle",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "mt-0.5 size-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "資料依 Tesla 車主手冊、官方支援頁與台灣常見實務整理，非原廠服務契約。實際週期以車內「控制 → 服務 → 保養」與 VIN 為準。勾選完成狀態僅存在本機瀏覽器。" })]
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MaintenanceGuide, {});
}
//#endregion
export { Home as component };
