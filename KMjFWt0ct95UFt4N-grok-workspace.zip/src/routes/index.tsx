import { createFileRoute } from "@tanstack/react-router";
import { MaintenanceGuide } from "@/components/maintenance-guide";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <MaintenanceGuide />;
}
