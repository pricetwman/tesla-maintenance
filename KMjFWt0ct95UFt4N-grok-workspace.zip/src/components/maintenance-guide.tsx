import { useMemo, useState } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  AlertTriangle,
  Check,
  ChevronDown,
  Clock,
  Gauge,
  Info,
  ShieldCheck,
  Wrench,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  ITEMS,
  MODELS,
  TIMELINE,
  dueStatus,
  itemApplies,
  modelById,
  type ItemKind,
  type MaintenanceItem,
  type ModelId,
} from "@/lib/maintenance";

type Filter = "all" | ItemKind;

interface GuideState {
  model: ModelId;
  km: number;
  years: number;
  done: string[];
  setModel: (m: ModelId) => void;
  setKm: (n: number) => void;
  setYears: (n: number) => void;
  toggleDone: (id: string) => void;
}

const useGuide = create<GuideState>()(
  persist(
    (set, get) => ({
      model: "y",
      km: 20000,
      years: 1,
      done: [],
      setModel: (model) => set({ model }),
      setKm: (km) => set({ km }),
      setYears: (years) => set({ years }),
      toggleDone: (id) => {
        const done = get().done.includes(id)
          ? get().done.filter((x) => x !== id)
          : [...get().done, id];
        set({ done });
      },
    }),
    { name: "tesla-service-guide" },
  ),
);

const KIND_LABEL: Record<ItemKind, string> = {
  official: "官方建議",
  preventive: "預防性",
  lifetime: "終身／視需要",
  "not-needed": "不需要",
};

function KindChip({ kind }: { kind: ItemKind }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide",
        kind === "official" && "bg-fg/10 text-fg",
        kind === "preventive" && "bg-warn/15 text-warn",
        kind === "lifetime" && "bg-ok/15 text-ok",
        kind === "not-needed" && "bg-subtle/20 text-muted",
      )}
    >
      {KIND_LABEL[kind]}
    </span>
  );
}

function ItemCard({
  item,
  km,
  years,
  done,
  onToggle,
}: {
  item: MaintenanceItem;
  km: number;
  years: number;
  done: boolean;
  onToggle: () => void;
}) {
  const [open, setOpen] = useState(false);
  const status = dueStatus(item, km, years);

  return (
    <article
      className={cn(
        "rounded-xl border border-border bg-surface p-4 md:p-5",
        done && "opacity-70",
      )}
    >
      <div className="flex items-start gap-3">
        <button
          type="button"
          onClick={onToggle}
          aria-label={done ? "取消完成" : "標記完成"}
          className={cn(
            "mt-0.5 flex size-11 shrink-0 items-center justify-center rounded-md border transition-colors duration-150",
            done
              ? "border-ok bg-ok text-bg"
              : "border-border bg-elevated text-muted hover:border-fg/30",
          )}
        >
          <Check className="size-4" strokeWidth={2.5} />
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-display text-base font-semibold tracking-tight text-fg">
              {item.name}
            </h3>
            <KindChip kind={item.kind} />
            {status === "due" && !done && (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-due">
                <AlertTriangle className="size-3.5" />
                依輸入里程／年數已到期
              </span>
            )}
            {status === "soon" && !done && (
              <span className="text-xs font-medium text-warn">即將到期</span>
            )}
          </div>
          <p className="mt-1 font-medium tabular-nums text-muted">{item.intervalLabel}</p>
          <p className="mt-2 text-sm leading-relaxed text-muted">{item.official}</p>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="mt-3 inline-flex min-h-11 items-center gap-1 text-sm font-medium text-fg"
          >
            {open ? "收合細節" : "看細節與實務建議"}
            <ChevronDown
              className={cn("size-4 transition-transform duration-150", open && "rotate-180")}
            />
          </button>
          {open && (
            <div className="mt-3 space-y-3 border-t border-border pt-3 text-sm leading-relaxed">
              {item.practice && (
                <p>
                  <span className="font-medium text-fg">實務建議：</span>
                  <span className="text-muted"> {item.practice}</span>
                </p>
              )}
              <p className="text-muted">{item.notes}</p>
              {item.parts && (
                <p className="font-mono text-xs text-subtle">零件編號 {item.parts}</p>
              )}
            </div>
          )}
        </div>
      </div>
    </article>
  );
}

export function MaintenanceGuide() {
  const { model, km, years, done, setModel, setKm, setYears, toggleDone } = useGuide();
  const [filter, setFilter] = useState<Filter>("all");
  const [timelineId, setTimelineId] = useState<string | null>(null);
  const current = modelById(model);

  const visible = useMemo(() => {
    let list = ITEMS.filter((i) => itemApplies(i, model));
    if (filter !== "all") list = list.filter((i) => i.kind === filter);
    if (timelineId) {
      const node = TIMELINE.find((t) => t.id === timelineId);
      if (node) list = list.filter((i) => node.itemIds.includes(i.id));
    }
    return list;
  }, [model, filter, timelineId]);

  const dueCount = ITEMS.filter(
    (i) =>
      itemApplies(i, model) &&
      dueStatus(i, km, years) === "due" &&
      i.kind !== "not-needed" &&
      !done.includes(i.id),
  ).length;

  const groups = useMemo(() => {
    const map = new Map<string, MaintenanceItem[]>();
    for (const item of visible) {
      const arr = map.get(item.group) ?? [];
      arr.push(item);
      map.set(item.group, arr);
    }
    return [...map.entries()];
  }, [visible]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4 md:px-6">
          <div className="flex items-center gap-3">
            <span className="flex size-9 items-center justify-center rounded-md bg-accent text-xs font-semibold tracking-widest text-accent-fg">
              T
            </span>
            <div>
              <p className="font-display text-sm font-semibold tracking-tight">Tesla 保養手冊</p>
              <p className="text-xs text-subtle">全車時間與項目</p>
            </div>
          </div>
          <p className="hidden text-xs text-subtle sm:block">以車內保養摘要為準</p>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 pb-20 pt-8 md:px-6 md:pt-12">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-subtle">Service calendar</p>
        <h1 className="font-display mt-3 max-w-2xl text-3xl font-semibold leading-tight tracking-tight md:text-5xl">
          特斯拉全車保養時間與項目
        </h1>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted">
          官方手冊沒有年度大保養。下面整理必做項目、台灣環境建議，以及減速器油、冷凝器這類預防性保養。選車型、填里程，即可看出目前該注意什麼。
        </p>

        <section className="mt-8 rounded-xl border border-border bg-surface p-4 md:p-6">
          <p className="text-sm font-medium text-fg">選擇車型</p>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-5">
            {MODELS.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setModel(m.id)}
                className={cn(
                  "min-h-11 rounded-md border px-3 py-2 text-sm font-medium transition-colors duration-150",
                  model === m.id
                    ? "border-fg bg-fg text-bg"
                    : "border-border bg-elevated text-muted hover:text-fg",
                )}
              >
                {m.name}
              </button>
            ))}
          </div>
          <p className="mt-3 text-sm text-muted">
            {current.fullName}　濾網：{current.cabinFilter}
          </p>
          <p className="mt-1 text-sm text-subtle">{current.heatPumpNote}</p>

          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="flex items-center gap-2 text-sm font-medium text-fg">
                <Gauge className="size-4" />
                目前里程（公里）
              </span>
              <input
                type="number"
                min={0}
                step={1000}
                value={km}
                onChange={(e) => setKm(Number(e.target.value) || 0)}
                className="mt-2 h-11 w-full rounded-md border border-border bg-elevated px-3 tabular-nums text-fg outline-none ring-fg/40 focus:ring-2"
              />
            </label>
            <label className="block">
              <span className="flex items-center gap-2 text-sm font-medium text-fg">
                <Clock className="size-4" />
                持有年數
              </span>
              <input
                type="number"
                min={0}
                max={20}
                step={0.5}
                value={years}
                onChange={(e) => setYears(Number(e.target.value) || 0)}
                className="mt-2 h-11 w-full rounded-md border border-border bg-elevated px-3 tabular-nums text-fg outline-none ring-fg/40 focus:ring-2"
              />
            </label>
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-3 rounded-lg bg-elevated px-4 py-3 text-sm">
            <ShieldCheck className="size-4 text-ok" />
            <span className="text-muted">
              依目前輸入，有{" "}
              <strong className="tabular-nums text-fg">{dueCount}</strong> 項已達官方或預防性週期（未勾完成）。
            </span>
          </div>
        </section>

        <section className="mt-10">
          <div className="flex items-end justify-between gap-4">
            <h2 className="font-display text-xl font-semibold tracking-tight">時間軸</h2>
            {timelineId && (
              <button
                type="button"
                onClick={() => setTimelineId(null)}
                className="min-h-11 text-sm text-muted hover:text-fg"
              >
                顯示全部項目
              </button>
            )}
          </div>
          <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            {TIMELINE.map((node) => (
              <button
                key={node.id}
                type="button"
                onClick={() => setTimelineId(timelineId === node.id ? null : node.id)}
                className={cn(
                  "rounded-lg border p-4 text-left transition-colors duration-150",
                  timelineId === node.id
                    ? "border-fg bg-elevated"
                    : "border-border bg-surface hover:border-fg/25",
                )}
              >
                <p className="font-display text-sm font-semibold">{node.label}</p>
                <p className="mt-1 text-xs text-subtle">{node.hint}</p>
              </button>
            ))}
          </div>
        </section>

        <section className="mt-10">
          <div className="flex flex-wrap gap-2">
            {(["all", "official", "preventive", "lifetime", "not-needed"] as Filter[]).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                className={cn(
                  "min-h-11 rounded-full border px-4 text-sm font-medium",
                  filter === f
                    ? "border-fg bg-fg text-bg"
                    : "border-border bg-transparent text-muted hover:text-fg",
                )}
              >
                {f === "all" ? "全部" : KIND_LABEL[f]}
              </button>
            ))}
          </div>

          <div className="mt-6 space-y-8">
            {groups.map(([group, items]) => (
              <div key={group}>
                <h3 className="mb-3 text-xs font-medium uppercase tracking-[0.16em] text-subtle">
                  {group}
                </h3>
                <div className="space-y-3">
                  {items.map((item) => (
                    <ItemCard
                      key={item.id}
                      item={item}
                      km={km}
                      years={years}
                      done={done.includes(item.id)}
                      onToggle={() => toggleDone(item.id)}
                    />
                  ))}
                </div>
              </div>
            ))}
            {groups.length === 0 && (
              <p className="rounded-lg border border-border bg-surface px-4 py-8 text-center text-sm text-muted">
                這個車型在此篩選下沒有對應項目。
              </p>
            )}
          </div>
        </section>

        <section className="mt-12 rounded-xl border border-border bg-surface p-5 md:p-6">
          <div className="flex items-start gap-3">
            <Wrench className="mt-0.5 size-5 shrink-0 text-muted" />
            <div>
              <h2 className="font-display text-lg font-semibold">如何避免壓縮機提前損壞</h2>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-relaxed text-muted">
                <li>定期清冷凝器與進氣口，不要讓樹葉、柳絮堵住散熱。</li>
                <li>準時換空調濾網，避免系統高風阻運轉。</li>
                <li>冷氣不冷、異音或儀表提示氣候系統故障，立刻檢查，不要硬開。</li>
                <li>聽到高頻嘯叫尤其是冷車時，盡快送修，避免金屬屑污染整組管路。</li>
              </ul>
            </div>
          </div>
        </section>

        <footer className="mt-10 flex items-start gap-2 text-xs leading-relaxed text-subtle">
          <Info className="mt-0.5 size-3.5 shrink-0" />
          <p>
            資料依 Tesla 車主手冊、官方支援頁與台灣常見實務整理，非原廠服務契約。實際週期以車內「控制 → 服務 →
            保養」與 VIN 為準。勾選完成狀態僅存在本機瀏覽器。
          </p>
        </footer>
      </main>
    </div>
  );
}
