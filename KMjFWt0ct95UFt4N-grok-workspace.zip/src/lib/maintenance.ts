export type ModelId = "3" | "y" | "s" | "x" | "ct";

export type ItemKind = "official" | "preventive" | "lifetime" | "not-needed";

export interface TeslaModel {
  id: ModelId;
  name: string;
  fullName: string;
  cabinFilter: string;
  hepa: boolean;
  heatPumpNote: string;
}

export interface MaintenanceItem {
  id: string;
  name: string;
  kind: ItemKind;
  group: "輪胎底盤" | "空調空氣" | "煞車" | "動力冷卻" | "電系耗材" | "不需保養";
  intervalKm?: number;
  intervalYears?: number;
  intervalLabel: string;
  official: string;
  practice?: string;
  appliesTo: ModelId[] | "all";
  notes: string;
  parts?: string;
}

export const MODELS: TeslaModel[] = [
  {
    id: "3",
    name: "Model 3",
    fullName: "Model 3 / Highland",
    cabinFilter: "每 2 年（台灣環境建議每年）",
    hepa: false,
    heatPumpNote: "約 2021 年起多數配備熱泵；舊款無熱泵才需定期換乾燥包。",
  },
  {
    id: "y",
    name: "Model Y",
    fullName: "Model Y / Juniper",
    cabinFilter: "每 2 年（台灣環境建議每年）",
    hepa: true,
    heatPumpNote: "全車系熱泵；乾燥包多數不需定期更換。",
  },
  {
    id: "s",
    name: "Model S",
    fullName: "Model S",
    cabinFilter: "每 3 年（2012–2020 建議每 2 年）",
    hepa: true,
    heatPumpNote: "新款熱泵；舊款乾燥包週期較短。",
  },
  {
    id: "x",
    name: "Model X",
    fullName: "Model X",
    cabinFilter: "每 3 年（2015–2020 建議每 2 年）",
    hepa: true,
    heatPumpNote: "新款熱泵；舊款乾燥包約每 4 年。",
  },
  {
    id: "ct",
    name: "Cybertruck",
    fullName: "Cybertruck",
    cabinFilter: "無標準車廂濾網；HEPA 每 2 年",
    hepa: true,
    heatPumpNote: "乾燥包約每 8 年。",
  },
];

export const ITEMS: MaintenanceItem[] = [
  {
    id: "tire-rotate",
    name: "輪胎換位",
    kind: "official",
    group: "輪胎底盤",
    intervalKm: 10000,
    intervalLabel: "每 10,000 km",
    official: "每 10,000 km，或前後胎紋差達 1.5 mm，以先到者為準。",
    notes:
      "電動車瞬間扭力會讓驅動輪磨得較快。RWD 後輪、AWD 四輪都要規律對調，才能維持續航與抓地。Model X 前後輪規格不同時無法交叉對調。",
    appliesTo: "all",
  },
  {
    id: "tire-align",
    name: "四輪定位",
    kind: "preventive",
    group: "輪胎底盤",
    intervalKm: 40000,
    intervalLabel: "約 40,000 km 或跑偏時",
    official: "無固定週期；輪胎異常磨損或方向盤跑偏時進行。",
    practice: "台灣路況建議每 4 萬公里或換胎時檢查。",
    notes: "路肩、坑洞、高速過彎後若方向盤不平，應盡快定位，避免單邊磨胎。",
    appliesTo: "all",
  },
  {
    id: "chassis",
    name: "底盤巡視與懸吊扭力",
    kind: "preventive",
    group: "輪胎底盤",
    intervalKm: 40000,
    intervalYears: 2,
    intervalLabel: "約 2 年 / 4 萬 km",
    official: "依需要檢查，非強制年度大保養。",
    practice: "原廠價目表有底盤巡視項目，建議搭配濾網或煞車油一起做。",
    notes: "膠套、球頭、連桿異音多半在 6 萬公里後出現。聽到底盤異音不要拖。",
    appliesTo: "all",
  },
  {
    id: "cabin-filter",
    name: "車廂空氣濾網（冷氣濾網）",
    kind: "official",
    group: "空調空氣",
    intervalYears: 2,
    intervalLabel: "每 1–2 年",
    official:
      "Model 3 / Y：手冊每 2 年；台灣／香港支援頁常列每 12 個月。Model S / X：每 3 年（2012–2020 年 S/X 每 2 年）。",
    practice: "台灣潮濕、空品差，建議每年更換，有霉味或風量變小立刻換。",
    notes:
      "Model 3 / Y 一次需換兩片。原廠常見編號 1107681-00-A / B / C。車內「控制 → 服務 → 保養」會顯示到期時間。",
    parts: "1107681-00-A / 1107681-00-B / 1107681-00-C（3 / Y 兩片一組）",
    appliesTo: ["3", "y", "s", "x"],
  },
  {
    id: "hepa",
    name: "HEPA 濾網與活性碳濾網",
    kind: "official",
    group: "空調空氣",
    intervalYears: 3,
    intervalLabel: "每 3 年",
    official:
      "配備 HEPA 者每 3 年更換 HEPA 與碳濾網。中國地區建議每年。Cybertruck 每 2 年，越野／土路每年。",
    notes: "Model Y、S、X 與 Cybertruck 常見配備。生化武器防禦模式依賴這組濾網。",
    appliesTo: ["y", "s", "x", "ct"],
  },
  {
    id: "desiccant",
    name: "冷氣乾燥包",
    kind: "official",
    group: "空調空氣",
    intervalYears: 6,
    intervalLabel: "視熱泵／年式",
    official:
      "多數熱泵車型不需定期預約更換。無熱泵舊款：Model 3（2017–2023）約 6 年；Model S 2012–2020 約 2 年；Model X 2015–2020 約 4 年；Cybertruck 約 8 年。",
    notes:
      "車內「控制 → 軟體 → 其他車輛資訊」可看是否有熱泵。有熱泵者以車內保養摘要為準。",
    appliesTo: "all",
  },
  {
    id: "condenser",
    name: "冷凝器／散熱網清潔",
    kind: "preventive",
    group: "空調空氣",
    intervalKm: 20000,
    intervalLabel: "每 1–2 萬 km",
    official: "灰塵環境下散熱器會堵塞，影響空調與電池散熱；依需要清潔。",
    practice: "台灣柳絮、落葉多，建議每 1–2 萬公里檢查前備箱進氣口與冷凝器。",
    notes:
      "斜置冷凝器容易只進不出。堵塞會讓壓縮機長時間高負荷，是壓縮機提前損壞的常見原因。可加裝防蟲網降低堆積。",
    appliesTo: "all",
  },
  {
    id: "wipers",
    name: "雨刷片",
    kind: "official",
    group: "空調空氣",
    intervalYears: 1,
    intervalLabel: "每年",
    official: "每年更換雨刷片。",
    notes: "可自行更換。雨刷水視需要補充。",
    appliesTo: "all",
  },
  {
    id: "brake-fluid",
    name: "煞車油檢查／更換",
    kind: "official",
    group: "煞車",
    intervalYears: 4,
    intervalLabel: "每 4 年",
    official: "每 4 年檢查煞車油狀況，必要時更換。",
    practice: "常拖車、下山、競技或炎熱潮濕環境需更頻繁。",
    notes:
      "動能回收讓摩擦煞車較少用，油品主要因吸水劣化，儀表不會主動提醒。不要自行補充煞車油。",
    appliesTo: "all",
  },
  {
    id: "calipers",
    name: "煞車卡鉗清潔潤滑",
    kind: "official",
    group: "煞車",
    intervalKm: 20000,
    intervalYears: 1,
    intervalLabel: "每年或 2 萬 km",
    official:
      "冬季撒鹽路面：每年或每 20,000 km 清潔並潤滑卡鉗滑銷。一般地區每年清潔。",
    notes: "台灣不撒鹽，但仍建議每年檢查卡鉗是否卡死，避免長期不用導致咬死。",
    appliesTo: "all",
  },
  {
    id: "pads",
    name: "煞車來令片",
    kind: "lifetime",
    group: "煞車",
    intervalLabel: "視磨損，多數很久才換",
    official: "動能回收大幅減少磨損，無固定里程。",
    notes: "仍需目視檢查厚度。山路、拖車、關閉動能回收會加快磨耗。",
    appliesTo: "all",
  },
  {
    id: "drive-oil",
    name: "馬達油／減速器油",
    kind: "preventive",
    group: "動力冷卻",
    intervalKm: 80000,
    intervalYears: 5,
    intervalLabel: "官方終身；預防性 6–12 萬 km",
    official:
      "驅動單元油列為終身免更換。特斯拉不需傳統機油保養。",
    practice:
      "獨立廠與高里程車主常見預防性更換：約 6–12 萬公里或 4–6 年。台灣高溫、市區走走停停可偏 6–8 萬公里。",
    notes:
      "這是齒輪潤滑油（ATF-9 / EDF2 / KAF1），不是引擎機油。原廠有「馬達油與油芯」服務項目。異音、漏粉紅油或買高里程二手車時優先檢查。",
    appliesTo: "all",
  },
  {
    id: "coolant",
    name: "電池冷卻液",
    kind: "lifetime",
    group: "動力冷卻",
    intervalLabel: "多數情況終身不換",
    official: "大多數情況下車輛壽命期間無需更換。液位僅能由 Tesla 或專業廠檢查。",
    notes: "自行打開冷卻液儲存缸造成的損壞不在保固範圍。",
    appliesTo: "all",
  },
  {
    id: "lv-battery",
    name: "低壓電瓶（12V / 16V）",
    kind: "preventive",
    group: "電系耗材",
    intervalYears: 4,
    intervalLabel: "約 3–6 年視狀況",
    official: "無固定週期；故障時更換。保固內部分可免費更換。",
    notes:
      "新款多為 16V 鋰電池。低壓電瓶老化會出現無法喚醒、中控當機、車門打不開。長期放置請保持適度電量。",
    appliesTo: "all",
  },
  {
    id: "cameras",
    name: "Autopilot 鏡頭清潔",
    kind: "official",
    group: "電系耗材",
    intervalLabel: "每週／視髒污",
    official: "定期清潔鏡頭與擋風玻璃內側攝影機區域。",
    notes: "髒污會影響輔助駕駛。前擋內側霧氣、油膜也要清。",
    appliesTo: "all",
  },
  {
    id: "engine-oil",
    name: "引擎機油、火星塞、燃油濾清器",
    kind: "not-needed",
    group: "不需保養",
    intervalLabel: "不需要",
    official: "純電無內燃機，不需換機油、火星塞、燃油系統或排放檢測。",
    notes: "「馬達油」是減速器齒輪油，與機油不是同一件事。",
    appliesTo: "all",
  },
];

export const TIMELINE: { id: string; label: string; hint: string; itemIds: string[] }[] = [
  {
    id: "weekly",
    label: "日常／每週",
    hint: "自己就能做",
    itemIds: ["cameras"],
  },
  {
    id: "10k",
    label: "每 10,000 km",
    hint: "最常做的項目",
    itemIds: ["tire-rotate"],
  },
  {
    id: "yearly",
    label: "每年",
    hint: "台灣建議提前做濾網",
    itemIds: ["wipers", "cabin-filter", "calipers", "condenser"],
  },
  {
    id: "2y",
    label: "每 2 年／約 4 萬 km",
    hint: "官方濾網與底盤",
    itemIds: ["cabin-filter", "chassis", "tire-align"],
  },
  {
    id: "3y",
    label: "每 3 年",
    hint: "HEPA 車型",
    itemIds: ["hepa"],
  },
  {
    id: "4y",
    label: "每 4 年",
    hint: "煞車油與低壓電瓶觀察",
    itemIds: ["brake-fluid", "lv-battery"],
  },
  {
    id: "80k",
    label: "6–12 萬 km",
    hint: "預防性，非官方強制",
    itemIds: ["drive-oil"],
  },
  {
    id: "life",
    label: "終身／視需要",
    hint: "官方多數不排程",
    itemIds: ["coolant", "pads", "desiccant", "engine-oil"],
  },
];

export function itemApplies(item: MaintenanceItem, model: ModelId) {
  return item.appliesTo === "all" || item.appliesTo.includes(model);
}

export function dueStatus(
  item: MaintenanceItem,
  km: number,
  years: number,
): "due" | "soon" | "ok" | "na" {
  if (item.kind === "not-needed" || item.kind === "lifetime") return "na";
  const kmDue = item.intervalKm != null && km >= item.intervalKm;
  const yrDue = item.intervalYears != null && years >= item.intervalYears;
  if (kmDue || yrDue) return "due";
  if (item.intervalKm != null && km >= item.intervalKm * 0.8) return "soon";
  if (item.intervalYears != null && years >= item.intervalYears * 0.8) return "soon";
  return "ok";
}

export function modelById(id: ModelId) {
  return MODELS.find((m) => m.id === id) ?? MODELS[0];
}
