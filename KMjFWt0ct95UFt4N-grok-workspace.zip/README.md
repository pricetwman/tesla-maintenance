# Tesla 保養手冊

特斯拉全車保養時間與項目一覽（Model 3 / Y / S / X / Cybertruck）。

可依車型、里程、持有年數查看官方週期與台灣常見預防性保養（濾網、煞車油、馬達油、冷凝器清潔等）。勾選完成狀態存在瀏覽器本機。

## 使用

選車型 → 填里程與年數 → 用時間軸或分類篩選 → 點開項目看細節。

實際保養仍以車內「控制 → 服務 → 保養」與 VIN 為準。

## 本機開發

需要 Node.js 22。

```bash
npm install
npm run dev
```

預設在 `http://localhost:8080`。

```bash
npm run build
```

## 技術

React 19、TanStack Start、Tailwind CSS v4。
